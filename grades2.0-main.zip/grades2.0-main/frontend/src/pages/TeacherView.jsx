import React from 'react';

function TeacherView() {
  return <h1>Teacher View</h1>;
}

export default TeacherView;