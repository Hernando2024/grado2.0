// src/pages/StudentView.js
import React from 'react';

function StudentView() {
  return <h1>Student View</h1>;
}

export default StudentView;